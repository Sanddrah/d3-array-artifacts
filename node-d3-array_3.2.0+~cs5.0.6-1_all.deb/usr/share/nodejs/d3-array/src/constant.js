export default function constant(x) {
  return () => x;
}
